package Project.src.main;

public class Constants {
    

    public static class ConstSnake{

        public static final String[] SNAKE_SPRITE_NAMES = 
            {"headUp", "headDown", "headLeft", "headRight", "tailUp", "tailDown", "tailLeft", "tailRight", "SegmentH","SegmentV"};
        public static final String[] FRUIT_SPRITE_NAMES = 
            {"Banana"};
    }
}
