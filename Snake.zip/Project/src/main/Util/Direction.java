package Project.src.main.Util;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT
}
