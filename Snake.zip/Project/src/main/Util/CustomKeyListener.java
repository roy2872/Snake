package Project.src.main.Util;

import java.awt.event.KeyListener;

public class CustomKeyListener implements KeyListener {

    public CustomKeyListener(){

    }

    @Override
    public void keyTyped(java.awt.event.KeyEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void keyPressed(java.awt.event.KeyEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void keyReleased(java.awt.event.KeyEvent e) {
        // TODO Auto-generated method stub
    }
    
}
