package Project.src.main.Util;

public enum FruitType {
    Banana
    
}
