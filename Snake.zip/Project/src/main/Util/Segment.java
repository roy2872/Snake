package Project.src.main.Util;

public class Segment {
    public int x, y;
    public Direction direction;

    public Segment(int x, int y, Direction direction) {
        this.x = x;
        this.y = y;
        this.direction = direction;
    }
}
